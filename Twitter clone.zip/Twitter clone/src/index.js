import './sass/main.scss';
import initSr from './js/sr';

initSr();
